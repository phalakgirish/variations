const KEYS = {
    apiPath:'http://localhost:9000/api/'
}

export default KEYS;