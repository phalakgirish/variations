# BlinkMacSystemFont

Apple system font full version

See the [demo](https://aliifam.github.io/BlinkMacSystemFont/)

Use at your own risk.

Obtained from [https://developer.apple.com/fonts/](https://developer.apple.com/fonts/)
